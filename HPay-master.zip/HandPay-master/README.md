# HandPay
HandPay project

# To start the project

- `npm run start-api` to start the little express server
- then `npm start` to start expo client, press `w` when you see the QR code to open the app on web browser 
